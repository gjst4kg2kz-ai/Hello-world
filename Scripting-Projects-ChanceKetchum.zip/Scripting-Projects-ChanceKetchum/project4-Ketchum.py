def compute_area(radius):
    """Compute the area of a circle given the radius."""
    return 3.14 * (radius ** 2)

def main():
    try:
        radius_input = input("Enter the radius of the circle: ").strip()

        radius = float(radius_input)
        if radius < 0:
            print("Error: Radius cannot be negative.")
            return

        area = compute_area(radius)

        print(f"The area of the circle with radius {radius} is: {area:.2f}")

    except ValueError:
        print("Invalid input. Please enter a numeric value for the radius.")

if __name__ == "__main__":
    main()