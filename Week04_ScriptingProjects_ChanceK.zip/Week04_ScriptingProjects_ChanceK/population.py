def main():
    print("Population Growth Predictor")

    initial = float(input("Enter the initial number of organisms: "))
    rate = float(input("Enter the growth rate (> 0): "))
    hours_per_cycle = float(input("Enter the number of hours to achieve this rate: "))
    total_hours = float(input("Enter the total number of hours for growth: "))

    cycles = total_hours / hours_per_cycle

    final_population = initial * (rate ** cycles)

    print(f"\nThe predicted population is: {final_population}")

if __name__ == "__main__":
    main()