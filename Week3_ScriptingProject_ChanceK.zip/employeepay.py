"""
File: employeepay.py
Inputs: hourly wage, total regular hours, total overtime hours
Outputs: total weekly pay
"""

hourlyWage = float(input("Enter the hourly wage: "))
regularHours = float(input("Enter total regular hours: "))
overtimeHours = float(input("Enter total overtime hours: "))

regularPay = hourlyWage * regularHours
overtimePay = overtimeHours * (1.5 * hourlyWage)
totalPay = regularPay + overtimePay

print("Total weekly pay: $", round(totalPay, 2))
