"""
File: minutes.py
Inputs: Number of years
Outputs: Number of minutes in that many years
"""

years = int(input("Enter the number of years: "))

minutes = years * 365 * 24 * 60

print("The number of minutes in", years, "years is", minutes)
