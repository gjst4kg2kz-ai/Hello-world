def main():
    try:
        base = float(input("Enter the base of the triangle: "))
        if base <= 0:
            print("Base must be a positive number.")
            input("\nPress Enter to exit...")
            return

        height = float(input("Enter the height of the triangle: "))
        if height <= 0:
            print("Height must be a positive number.")
            input("\nPress Enter to exit...")
            return

        area = 0.5 * base * height

        print(f"The area of the triangle is: {area:.2f}")

    except ValueError:
        print("Invalid input. Please enter numeric values for base and height.")

    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()