import math

def main():
    print("Think of a number in a range and I will guess it.")

    low = int(input("Enter the lower bound: "))
    high = int(input("Enter the upper bound: "))

    max_guesses = math.ceil(math.log(high - low + 1, 2))
    print("I will guess your number in no more than", max_guesses, "guesses.")

    guesses = 0

    while low <= high:
        guess = (low + high) // 2
        guesses += 1

        print("My guess is:", guess)
        hint = input("Enter h for too high, l for too low, or c for correct: ")

        if hint == "c":
            print("I guessed your number in", guesses, "tries.")
            return

        if hint == "h":
            high = guess - 1
        elif hint == "l":
            low = guess + 1
        else:
            print("Invalid input. Use h, l, or c.")
            guesses -= 1
            continue

        if guesses > max_guesses:
            print("Your hints are inconsistent. Cheating detected.")
            return

    print("Your hints do not match any possible number. Cheating detected.")

main()
