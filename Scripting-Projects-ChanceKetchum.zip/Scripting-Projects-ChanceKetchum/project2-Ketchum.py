try:
    width = float(input("Enter the width: "))
    height = float(input("Enter the height: "))

    if width < 0 or height < 0:
        print("Width and height must be non-negative numbers.")
    else:
        area = width * height
        print(f"The area is {area} square units.")

except ValueError:
    print("Invalid input. Please enter numeric values for width and height.")
