def main():
    print("This program calculates the total distance traveled by a bouncing ball.")

    height = float(input("Enter the initial height of the drop(ft): "))
    bounciness = float(input("Enter the bounciness index (0–1): "))
    bounces = int(input("Enter the number of bounces: "))

    total_distance = height  # initial drop
    current_height = height

    for _ in range(bounces):
        current_height *= bounciness
        total_distance += 2 * current_height

    print(f"\nTotal distance traveled: {total_distance} feet")

if __name__ == "__main__":
    main()