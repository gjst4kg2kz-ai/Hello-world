print("Name: Chance Ketchum")
print("Address: 5616 w Austin st, BA, 74011")
print("Telephone: (918) 520-9460")
input("Press Enter to exit...")