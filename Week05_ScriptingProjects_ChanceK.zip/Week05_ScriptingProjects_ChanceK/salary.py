def main():
    start_salary = float(input("Enter the starting salary: "))
    percent_increase = float(input("Enter the percentage increase: "))
    years = int(input("Enter the number of years: "))

    print(f"{'Year':<10}{'Salary':<15}")

    salary = start_salary

    for year in range(1, years + 1):
        print(f"{year:<10}{salary:<15.2f}")
        salary = salary + (salary * percent_increase / 100)

main()
