# copyfile.py
# Prompts the user for two filenames
# Copies the contents of the first file into the second file

sourceName = input("Enter the name of the file to copy from: ")
targetName = input("Enter the name of the file to copy to: ")

sourceFile = open(sourceName, "r")

targetFile = open(targetName, "w")

contents = sourceFile.read()
targetFile.write(contents)

sourceFile.close()
targetFile.close()

print("File copy complete.")
